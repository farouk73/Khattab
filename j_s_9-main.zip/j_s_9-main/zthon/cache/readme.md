To store cache file of alpop
