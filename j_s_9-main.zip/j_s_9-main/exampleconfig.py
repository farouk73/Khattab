from sample_config import Config


class Development(Config):
    # ضـع اكـوادك تحت مكـان الكـلام العـربي  .. امسـح الكلام العربي اللي بين " " فقـط وضع اكـوادك
    APP_ID = 6 #ضع كود الايبي ايدي الصغيـر مكان الرقم 6 نسخ لصق   
    API_HASH = "ضع كود الايبي هاش"
    ALIVE_NAME = "اسم حسابك التلي"
    DB_URI = "رابـط التخـزين الخـاص بك"
    STRING_SESSION = "كود تيرمــكس"
    TG_BOT_TOKEN = "توكـن البـوت الخـاص بك"
    PRIVATE_GROUP_BOT_API_ID = -100  # ضـع ايـدي كـروب السجـل بجـانب العـدد -100 لا تمسـح العـدد هـذا
    COMMAND_HAND_LER = "."  # اتركهــا كمـا هـي
    SUDO_COMMAND_HAND_LER = "."  # اتركهــا كمـا هـي
    TZ = "Asia/Baghdad"  # اتركهــا كمـا هـي
