python3 -m zthon
